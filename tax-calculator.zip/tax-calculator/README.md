# Simple tax calculator
Simple tax calculator 

cd tax-calculator

    ionic platform add android 

    ionic build android

    ionic run android 
