[
{
	"earningPoint" : 0,
	"coef_A" : 0.0,
	"coef_B" : 0.0

},
{
	"earningPoint" : 355,
	"coef_A" : 19.00,
	"coef_B" : 67.4635

},
{
	"earningPoint" : 395,
	"coef_A" : 29.00,
	"coef_B" : 106.9673
},
{
	"earningPoint" : 493,
	"coef_A" : 21.00,
	"coef_B" : 67.4635
},
{
	"earningPoint" : 711,
	"coef_A" : 34.77,
	"coef_B" : 165.4431
},
{
	"earningPoint" : 1282,
	"coef_A" : 34.50,
	"coef_B" : 161.9815
},
{
	"earningPoint" : 1538,
	"coef_A" : 39.00,
	"coef_B" : 231.2123
},
{
	"earningPoint" : 3461,
	"coef_A" : 49.00,
	"coef_B" : 577.3662
}
]
