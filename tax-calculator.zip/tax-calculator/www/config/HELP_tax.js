[
{
	"earningPoint" : 0,
	"coef_A" : 0.0
},
{
	"earningPoint" : 1040,
	"coef_A" : 4.0
},
{
	"earningPoint" : 1159,
	"coef_A" : 4.5
},
{
	"earningPoint" : 1278,
	"coef_A" : 5.0
},
{
	"earningPoint" : 1345,
	"coef_A" : 5.5
},
{
	"earningPoint" : 1445,
	"coef_A" : 6.0
},
{
	"earningPoint" : 1566,
	"coef_A" : 6.5
},
{
	"earningPoint" : 1648,
	"coef_A" : 7.0
},
{
	"earningPoint" : 1814,
	"coef_A" : 7.5
},
{
	"earningPoint" : 1933,
	"coef_A" : 8.0
}
]
