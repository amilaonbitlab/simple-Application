// Tax Controller js 
angular.module('starter.controllers', [])
// Start Tax Ctrl 
.controller('TaxCtrl', 
  // inject defendancy 
  ['$scope','readJsonFile','$ionicPopup', 
  // function 
  function($scope,readJsonFile,$ionicPopup) {

  // confit variable 
  $scope.taxableIncome = '';
  $scope.PAYG_Tax= 0;
  $scope.HELP_Tax = 0;
  $scope.totalTax = 0;
  $scope.netIncome = 0;

  // Calculate Weekly Pay Tax
  $scope.calWeekTax = function(taxableIncome){
    // console.log(taxableIncome);

    // Check taxable amount positive 
    if(taxableIncome >= 0){
      
        // init Co-efficent A and Co-effeicent B 
        var coef_A = 0;
        var coef_B = 0;
        
        // Read PAYG Tax File      
        readJsonFile.read('PAYG').success(function(data){
            //console.log(data);
            
            // according tax amount set coef_A and coef_B values 
            for(var i = 0; i < data.length; i++){
                //console.log(data[i]);
                
                // check range applicable taxableIncome                 
                if(data[i]['earningPoint'] > taxableIncome){
                  coef_A = data[i-1]['coef_A'];
                  coef_B = data[i-1]['coef_B'];
                  break;
                }
            }            
            //console.log("coef_A"+ coef_A);
            //console.log("coef_B"+ coef_B);
            
            // Calulate PAYG Tax 
            // PAYG Tax = ( Taxable Income * ( coef_A / 100) ) - coef_B
            $scope.PAYG_Tax = ( taxableIncome * ( coef_A / 100) ) - coef_B;   

            // Round up two decimal number 
            $scope.PAYG_Tax  = Math.round($scope.PAYG_Tax * 100) / 100;

            // Read HELP Tax File      
            readJsonFile.read('HELP').success(function(dataHELP){
                // console.log(dataHELP);
                coef_A = 0;
                // according tax amount set coef_A
                for(var i = 0; i < dataHELP.length; i++){
                    // console.log(dataHELP[i]);
                    
                    // check range applicable taxableIncome                 
                    if(dataHELP[i]['earningPoint'] > taxableIncome){
                      coef_A = dataHELP[i-1]['coef_A'];                    
                      break;
                    }
                }            
                //console.log("coef_A"+ coef_A);
              
                // Calulate PAYG Tax 
                // Help Tax = ( Taxable Income * ( coef_A / 100) ) - coef_B
                $scope.HELP_Tax = ( taxableIncome * ( coef_A / 100) );   

                // Round up two decimal number 
                $scope.HELP_Tax  = Math.round($scope.HELP_Tax * 100) / 100

                //console.log($scope.PAYG_Tax);
                //console.log($scope.HELP_Tax);

                // Total Tax = PAYG Tax + Help Tax 
                $scope.totalTax = $scope.PAYG_Tax + $scope.HELP_Tax;
                // Net Income = Taxable Income - Total Tax 
                $scope.netIncome = taxableIncome - $scope.totalTax;

            });

        });

    }else{
      $scope.taxableIncome = '';
      // If invalid Amount, Pop up message 
      $ionicPopup.alert({
          title: 'Invalid Taxable Amount',
          template: 'Please enter correct taxable amount'
        });

    }
    
  }

}]);