angular.module('starter.services', [])
// read json file service 
.service('readJsonFile', function($http) {

	// read Tax File given name 
    this.read = function(fileName)
    {
        return $http({
            method: 'GET',
            url: 'config/'+fileName+'_tax.js',
        });
    }
});